#include "abstractautomaton.h"

State *AbstractAutomaton::getStartingState() const
{
    return startingState;
}

AbstractAutomaton::~AbstractAutomaton()
{

}
